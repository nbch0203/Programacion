package modelo;

public class Alumno {
	private int id;
	private String nombre;
	private int edad;
	private Double nota;

	public Alumno(int id, String nombre, int edad, Double nota) {
		this.id = id;
		this.nombre = nombre;
		this.edad = edad;
		this.nota = nota;
	}

	public Alumno(String nombre, int edad, Double nota) {
		this.nombre = nombre;
		this.edad = edad;
		this.nota = nota;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public Double getNota() {
		return nota;
	}

	public void setNota(Double nota) {
		this.nota = nota;
	}

	@Override
	public String toString() {
		return "Id = " + getId() + " -  Nombre : " + getNombre() + " - Edad = " + getEdad() + " - Nota = " + getNota()
				+ "\n";
	}

}
